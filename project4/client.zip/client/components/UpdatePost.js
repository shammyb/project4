//import React from 'react'
import React, { useState } from 'react'
import axios from 'axios'

function UpdatePost() {
 
  return <div>
    <h1>Update Post</h1>
  </div>
  

}

export default UpdatePost