export default [
  { value: 'arabic', label: 'Arabic' },
  { value: 'english', label: 'English' },
  { value: 'french', label: 'French' },
  { value: 'hebrew', label: 'Hebrew' },
  { value: 'mandarin', label: 'Mandarin' },
  { value: 'spanish', label: 'Spanish' }
]